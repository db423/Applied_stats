%macro T_CG_BW_R2_diff(dataset=,variable=,n=,m=,labelfmt1=,labelfmt2=);
data stat;
	set &dataset.;
	stat_var=input(&variable,best12.);
	if fasfl='1';
	if &group.="&n." then group2="1";
	if &group.="&m." then group2="2";
	if group2='' then delete;
run;
proc sort data=stat;by group2;run;

  DATA TEST_OUT;
    _LRCHI_='  NA';
    P_LRCHI='  NA';
    XP2_FISH='  NA';
  RUN;


  proc freq data=stat noprint;
    tables group2*&variable/sparse outpct outexpect out=freq_out chisq fisher;
	output out=test_out chisq fisher;
run;
  proc freq data=stat noprint;
    tables group2*&variable./ALPHA=0.05 riskdiffc  
     out=check1;
     output RISKDIFF2 RISKDIFF1 out=rdiff;  
  run;

  data rdiff_1;
    set rdiff;
	E_RDIF=compress(round(_RDIF1_*100,0.01)||''||'%');
	L_RDIF=compress(round(L_RDIF1*100,0.01)||''||'%');
	U_RDIF=compress(round(U_RDIF1*100,0.01)||''||'%');
	keep E_RDIF L_RDIF U_RDIF;
  run;

  data rdiff_2;
	  set rdiff_1;
  run;

  data rdiff_;
	  set rdiff_1 rdiff_2;
  run;

  data freq_out;set freq_out;
    if &variable~=' ';
    if expected<5 then mark=1;
    else mark=0;
	run;
  proc sort;by group2;run;

  proc univariate data=freq_out noprint;
    var mark;
	output out=select n=m_n sum=m_sum;
  run;

  data test_out;
    merge test_out select;
    select=m_sum/m_n;
  run;

  /* Count the Missing Frequency */
  proc univariate data=stat noprint;
    by group2;
    var stat_var;
	output out=total_n n=n nmiss=nmiss;
  proc sort;by group2;*PROC PRINT;RUN;
  run;

  %blank(1);
  data test_out;set blank test_out;
	varname="&variable";
	drop n;*PROC PRINT;RUN;
	run;
  data test_out;
    merge total_n test_out;
    labelfmt1="&labelfmt1";
		run;
  proc sort;by group2;	
  run;
  data freq_out;
    set freq_out;varname="&variable";
	mid=_n_;
  run;

  data freq_out1;
  	set freq_out;
	if group2=1;
	mid=_n_;
  run;

  data freq_out2;
  	set freq_out;
	if group2=2;
  run;

  data freq_out2;
  	set freq_out2;
	mid=_n_;
  run;

  data e1;
    do i=1 to 2;
      PCT_ROW=0;count=0;mid=i;group2='1';&variable=put(i,1.);
	  output;
	end;
	run;

  data e2;
    do i=1 to 2;
      PCT_ROW=0;count=0;mid=i;group2='2';&variable=put(i,1.);
	  output;
	end;
	run;

  proc sort data=freq_out1;by &variable;run;
  proc sort data=freq_out2;by &variable;run;
  proc sort data=e1;       by &variable;run;
  proc sort data=e2;       by &variable;run;

  data freq_out11;
  update e1 freq_out1;
  by &variable;
  run;

  data freq_out22;
  update e2 freq_out2;
  by &variable;
  run;

  data freq_outall;
  	set freq_out11 freq_out22;
  run;
 
  data test_out_final;
	  merge rdiff_ test_out;
	  keep E_RDIF L_RDIF L_RDIF U_RDIF P_PCHI;
  run;
  
	proc print data=test_out_final;run;

%mend T_CG_BW_R2_diff;
