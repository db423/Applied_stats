
/******************************************************************************/


%macro M_CG_BW_R_ALL_NT(dataset=,variable=,group=,blm=,blz=,labelfmt=);

	data freqdata(keep=&group. &variable.);
		set &dataset.;
		if group='5' then delete;
		if &blm.="&blz.";
		if input(&variable.,best12.)=. then delete;
	run; 
	ods listing close;
	proc tabulate data=freqdata out=freq_g1(drop=_type_ _page_ _table_);
		class &group. &variable./preloadfmt  ;
		table &variable.*(n colpctn),&group./ printmiss row=float;
		format &group.  $&group.f. &variable.  $&variable.f.;
	run;

	proc freq data=freqdata noprint;
		tables &group*&variable/sparse outpct outexpect chisq;
		output out=test_out chisq;
	run;

	ods listing;
	data freq_g2;
		set freq_g1;
		if n=. then n=0;
		if pctn_10=. then pctn_10=0;
		format &group. &group.;
		var1=&variable.;
	run;
	proc freq data=freqdata noprint ;
		tables &group.*&variable./sparse outpct outexpect out=freq_out;
	run;
	data freq_out1;
		set freq_out;
		var1=&variable.;
		if &variable.~="";
	run;
	proc sort data=freq_g2;    by &group. var1;run;
	proc sort data=freq_out1;  by &group. var1;run;
	data freq_out2(keep=&group. &variable. expected n pctn_10 rename=(n=count pctn_10=pct_row));
		merge freq_out1 freq_g2;
		by &group. var1;
		if expected=. then expected=0;
	run;
	proc sort data=freq_out2;by &group.;run;


	data stat(keep=&group. &variable. stat_var);
		set &dataset.;
		if group='5' then delete;
		if &blm.="&blz.";
		if &variable.="." then &variable.="";
		stat_var=input(&variable.,best12.);
	run;
	proc univariate data=stat noprint;
		class &group.;
		var stat_var;
		output out=total_n n=n nmiss=nmiss;
	run;
	data test_out1;set total_n;run;




	/*************************************************************/




	data freqdata(keep=&variable.);set &dataset.;run; 
	ods listing close;
	proc tabulate data=freqdata out=freq_g1(drop=_type_ _page_ _table_) ;
		class &variable./ preloadfmt;/* preloadfmt��specifies that all formats are preloaded for the class variables.*/
		table  &variable.*(n pctn)/ printmiss row=float;
		/* Use care when you use PRELOADFMT with PRINTMISS. This feature creates all possible combinations of formatted class variables.*/
		/*row=float:divides the row title space equally among the nonblank row titles in the crossing.*/
		format &variable.  $&variable.f.;
	run;
	ods listing;
	data freq_out(rename=(n=count pctn_0=percent));
		set freq_g1;
		if n=. then n=0;
		if pctn_0=. then pctn_0=0;
	run;

	data stat;
		set &dataset.;
		if group='5' then delete;
		if &blm.="&blz.";
		if &variable.="." then &variable.="";
		if &variable.="" then stat_var=.;
		else stat_var=1;
	run;
	proc univariate data=stat noprint;
		var stat_var;
		output out=total_n n=n nmiss=nmiss;
	run;
	data test_out;
		set test_out;
		&group.='Z';
	run;
	proc sort data=test_out;by &group.;run;

	/*************************************************************/


	data freq_out2;
		set freq_out2;
		rename pct_row=percent;
	run;
	data freq_out3;
		set freq_out2 freq_out;
		if &group.='' then &group.='3';
		if EXPECTED=. then delete;
	run;
	data ttest;
		set test_out1 total_n;
		if &group.='' then &group.='3';
	run;

	proc print data=freq_out3;run;
	proc print data=ttest;run;
	data test_out_;set test_out;keep P_LRCHI;run;
	proc print data=test_out_;run;

%mend M_CG_BW_R_ALL_NT;


