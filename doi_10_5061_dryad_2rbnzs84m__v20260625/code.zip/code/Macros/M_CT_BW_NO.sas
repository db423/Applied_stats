%macro M_CT_BW_NO(dataset=,variable=,ParSel=,group=,labelfmt=);
	data stat;
		set &dataset;
		stat_var=input(&variable,best12.);
	run;
	proc sort data=stat;by &group;run;

	proc univariate data=stat noprint;
		var stat_var;by &group;
		output out=desc_out n=n mean=mean std=std min=min max=max median=median q1=q1 q3=q3 nmiss=nmiss;
	run;
	data desc_out;set desc_out;varname="&variable";run;
	proc sort data=desc_out;by &group;run;

	%if &ParSel=1 %then %do;
	data statp;set &dataset;if group~='5';stat_var=input(&variable,best12.);run;
	ods listing close;
	ods trace on/listing;
	ods output ModelANOVA=ModelANOVA;
	proc glm data=statp;
		class &group;
		model stat_var=&group/ss3;
	run;
	ods trace off;
	ods listing;

	data ModelANOVA;set ModelANOVA;&group='Z';run;
	proc sort data=ModelANOVA;by &group;run;

	proc print data=ModelANOVA;run;
	proc print data=desc_out;run;

	%end;

	%else %if &ParSel=2 %then %do; 
	data statp;set &dataset;if group~='5';stat_var=input(&variable,best12.);run;
	proc npar1way data=statp noprint;
		class &group;
		var stat_var;
		output out=ttests WILCOXON;
	run;
	data ttests;
		set ttests;
		&group='Z';
	run;
	proc sort data=ttests;by &group;run;
	proc print data=ttests;run;
	proc print data=desc_out;run;
	%end;

%mend M_CT_BW_NO;



