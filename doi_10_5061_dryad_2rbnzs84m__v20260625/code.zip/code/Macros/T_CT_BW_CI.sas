
%macro T_CT_BW_CI(dataset=,variable=,parsel=,n=,m=,labelfmt=);



   data stat(keep=&variable. group2 stat_var);
  	 set &dataset.;
		if fasfl='1';
		if &group.="&n." then group2="1";
		if &group.="&m." then group2="2";
		if group2='' then delete;
     stat_var=input(&variable.,best12.);
   run;

   proc univariate data=stat noprint;
  	  class group2;
      var stat_var;
	  output out=desc_out n=n mean=mean std=std min=min max=max median=median q1=q1 q3=q3 nmiss=nmiss;
   run;

   proc means data=stat clm noprint;
   	  class group2;
	  var stat_var;
	  output out=desc_outa lclm=lclm uclm=uclm;
   run;
   data desc_outa_(keep=group2 lclm uclm);
   	  set desc_outa;
	  if group2~="";
   run;
   proc sort data=desc_outa_;by group2;run;
   proc sort data=desc_out;  by group2;run;

	data desc_out1(keep=n nmiss mean_ std_ median_ min_ max_ q1_ q3_ lclm_ uclm_ meancl group2);
		merge desc_out desc_outa_;
		by group2;
		if mean~=. then mean_=trim(left(put(round(mean,0.01),6.2)));
	    else  mean_="  NA";
		if std~=. then std_=trim(left(put(round(std,0.01),6.2)));
	    else  std_="  NA";
		if min~=. then min_=trim(left(put(round(min,0.01),6.2)));
	    else  min_="  NA";
		if max~=. then max_=trim(left(put(round(max,0.01),6.2)));
	    else  max_="  NA";
		if median~=. then median_=trim(left(put(round(median,0.01),6.2)));
	    else  median_="  NA";
		if q1~=. then q1_=trim(left(put(round(q1,0.01),6.2)));
	    else  q1_="  NA";
		if q3~=. then q3_=trim(left(put(round(q3,0.01),6.2)));
	    else  q3_="  NA";

		if lclm~=. then lclm_=trim(left(put(round(lclm,0.01),6.2)));
	    else  lclm_="  NA";

		if uclm~=. then uclm_=trim(left(put(round(uclm,0.01),6.2)));
	    else  uclm_="  NA";
		if lclm~=. then meancl=" ["||trim(left(lclm_))||", "||trim(left(uclm_))||"]";
		else meancl="  NA"||" ["||"  NA"||","||"  NA"||"]";
	run;
    proc sort data=desc_out1;by group2;run;

	%if  &parsel.=1 %then  %do;
		  ods listing close;
		  ods trace on/listing;
		  ods output TTests=ttests Equality=equality  ConfLimits=cl;
		    proc ttest data=stat;
		    	class group2;
		    	var stat_var;
		    run;
		  ods trace off;
		  ods listing;

		  data _null_;	set equality;call symput("variancep",input(ProbF,best12.));run;
		  data testdata1(keep=svalue pvalue);
			set ttests;
	        variancep=&variancep.;
			if variancep>=0.05 and method="����" then mark=1;
			else if .<variancep<0.05 and method="Satterthwaite" then mark=1;
			else mark=0;
			if mark=1;
		    svalue=tvalue;
			pvalue=trim(left(put(probt,PVALUE6.4)));
		 run;
		 proc sql noprint;
			select count(svalue) into :obsnum from testdata1;
		 quit;
		 %if &obsnum. ne 0 %then %do; 
			 data testdata;
			 	set testdata1;
			run;
		%end;
		%else %do;
		    data testdata(keep=svalue pvalue);
			   svalue="  NA";
			   pvalue="  NA";
		    run;
		%end;
		  data cl1(keep=group2 diffcl);
			set cl;
	        variancep=&variancep.;
			if variancep>=0.05 and method="����" then mark=1;
			else if .<variancep<0.05 and method="Satterthwaite" then mark=1;
			else mark=0;
			if mark=1;
			group2="1";
			diffcl=trim(left(trim(left(put(round(Mean,0.01),6.2)))||" ["||trim(left(put(round(LowerCLMean,0.01),6.2)))||", "||trim(left(put(round(UpperCLMean,0.01),6.2)))||"]"));
		 run;
		 proc sql noprint;
			select count(diffcl) into :obsnum from cl1;
		 quit;
		 %if &obsnum. ne 0 %then %do; 
			 data cltotal;
			 	set cl1;
			run;
		%end;
		%else %do;
		    data cltotal(keep=group2 diffcl);
				diffcl="  NA"||" ["||"  NA"||","||"  NA"||"]";
				group2="1";
		    run;
		%end;
   %end;

	%if  &parsel.=2  %then  %do;
		proc npar1way data=stat hl noprint;
		    class group2;
		    var stat_var;
			output out=ttests wilcoxon hl;
		run;
		data ttests;
			set ttests;
			HL_reversed=-_HL_;
			wL_HL=-L_HL;
			wU_HL=-U_HL;
		run;
		 proc sql noprint;
			select count(_var_) into :obsnum from ttests;
		 quit;
		 %if &obsnum. ne 0 %then %do; 
	 		data testdata(keep=svalue pvalue);
				set ttests;
				svalue=z_wil;
				pvalue=trim(left(put(p2_wil,PVALUE6.4)));
			run;
	 		data cltotal(keep=group2 diffcl);
				set ttests;
			    diffcl=trim(left(trim(left(put(round(HL_reversed,0.01),6.2)))||" ["||trim(left(put(round(wU_HL,0.01),6.2)))||", "||trim(left(put(round(wL_HL,0.01),6.2)))||"]"));
                group2="1";
           run;
		 %end;
		 %else %do;
	 		data testdata(keep=svalue pvalue);
				svalue="  NA";
				pvalue="  NA";
			run;
	 		data cltotal(keep=group2 diffcl);
				diffcl="  NA"||" ["||"  NA"||","||"  NA"||"]";
			    group2="1";
			run;
		 %end;
	%end;

	proc sort data=desc_out1;by descending group2;run;
	data unin_mode;merge testdata desc_out1;run;

	proc sort data=unin_mode;by group2;run;

data unin_mode_;set unin_mode;keep pvalue;run;
proc print data=unin_mode_;run;
proc print data=cltotal;run;

%mend T_CT_BW_CI;
  
  
  
