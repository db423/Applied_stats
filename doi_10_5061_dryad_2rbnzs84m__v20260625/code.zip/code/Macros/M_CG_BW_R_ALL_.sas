%macro M_CG_BW_R_ALL_(dataset=,variable=,group=,labelfmt=);
/****************************************    ****************************************/
  options ls=256 ps=200;

  data stat;
    set &dataset.;
    stat_var=input(&variable.,best12.);
	if &variable.='' then delete;
  proc sort;by &group;


  proc freq data=stat noprint;
    tables &group.*&variable./sparse outpct outexpect out=freq_out;
  run;


/* Count the Missing Frequency */
  data stat0;
    set &dataset.;
	if &variable.='' then flag=.;
		else flag=1;

  proc sort;by &group;
  run;

  proc univariate data=stat0 noprint;
    by &group.;
    var flag;
	output out=total_n n=n nmiss=nmiss;
  proc sort;by &group.;*PROC PRINT;RUN;
  run;

  proc univariate data=stat0 noprint;
	var flag;
	output out=total_nall n=n nmiss=nmiss;
  run;

 data total_n;
    set total_nall total_n;
	if &group.~='';
  run;



 data dataset1 dataset2;
	set stat;
	if &group. in ('2','3') then output dataset1;
	if &group. in ('4','5') then output dataset2;
run;

data test_out1;
	    _lrchi_="  NA";
	    p_lrchi="  NA";
	    xp2_fish="  NA";
    run;

data freqdata1(keep=&group. &variable.);
		set dataset1;
		if input(&variable.,best12.)=. then delete;
    run; 
	ods listing close;
    proc tabulate data=dataset1 out=freq_g1(drop=_type_ _page_ _table_);
		class &group. &variable./preloadfmt  ;
		/*preloadfmt��specifies that all formats are preloaded for the class variables.*/
        table &variable.*(n colpctn),&group./ printmiss row=float;*ҳ/��/��ά��;
		/* Use care when you use PRELOADFMT with PRINTMISS. This feature creates all possible combinations of formatted class variables.*/
        /*row=float:divides the row title space equally among the nonblank row titles in the crossing.*/
	    format &group.  $&group.f. &variable.  $&variable.f.;
	run;
	ods listing;


	data freq_g1;
		set freq_g1;
		if n=. then n=0;
		if pctn_10=. then pctn_10=0;
		format &group. &group.;
		var1=&variable.;
		if &group. in ('2','3');
	run;
	proc freq data=freqdata1 noprint ;
	    tables &group.*&variable./sparse outpct outexpect out=freq_out1 chisq fisher;
		output out=test_out1 chisq fisher;
	run;
	data freq_out1;
		set freq_out1;
		var1=&variable.;
		if &variable.~="";
	run;
	proc sort data=freq_g1;    by &group. var1;run;
	proc sort data=freq_out1;  by &group. var1;run;
	data fout1(keep=&group. &variable. expected n pctn_10 rename=(n=count pctn_10=pct_row));
		merge freq_out1 freq_g1;
		by &group. var1;
		if expected=. then expected=0;
	run;
	proc sort data=fout1;by &group.;run;

	data expected1;
		set fout1;
		if expected<5 then mark=1;
		else mark=0;
	run;
	proc sql noprint;
	   select avg(mark),sum(expected) into :methodselect1,:sumexpected1  from expected1;
	   quit;
	run;
	data _null_;
		set test_out1;
		if xp2_fish="  NA" then do;
			call symput("p_fisher1","  NA");
			call symput("x_fisher1","  NA");
		end;	  
		else if input(xp2_fish,best12.)~=. then do;
			call symput("p_fisher1",trim(left(put(xp2_fish,6.4))));
			call symput("x_fisher1","Fisher");
        end;
		else do;
			call symput("p_fisher1","  NA");
			call symput("x_fisher1","  NA");
        end;
		if _lrchi_="  NA" then call symput("lrchi1","  NA");
		else if input(_lrchi_,best12.)~=. then call symput("lrchi1",trim(left(put(_lrchi_,6.4))));
		else call symput("lrchi1","  NA");
		if p_lrchi="  NA" then call symput("p_lrchi1","  NA");
		else if input(p_lrchi,best12.)~=. then 	call symput("p_lrchi1",trim(left(put(p_lrchi,6.4))));
		else call symput("p_lrchi1","  NA");
	run;



    data test_out2;
	    _lrchi_="  NA";
	    p_lrchi="  NA";
	    xp2_fish="  NA";
    run;
	data freqdata2(keep=&group. &variable.);
		set dataset2;
		if input(&variable.,best12.)=. then delete;
    run; 
	ods listing close;
    proc tabulate data=dataset2 out=freq_g2(drop=_type_ _page_ _table_);
		class &group. &variable./preloadfmt  ;
		/*preloadfmt��specifies that all formats are preloaded for the class variables.*/
        table &variable.*(n colpctn),&group./ printmiss row=float;
		/* Use care when you use PRELOADFMT with PRINTMISS. This feature creates all possible combinations of formatted class variables.*/
        /*row=float:divides the row title space equally among the nonblank row titles in the crossing.*/
	    format &group.  $&group.f. &variable.  $&variable.f.;
	run;
	ods listing;


	data freq_g2;
		set freq_g2;
		if n=. then n=0;
		if pctn_10=. then pctn_10=0;
		format &group. &group.;
		var1=&variable.;
		if &group. in ('4','5');
	run;
	proc freq data=freqdata2 noprint ;
	    tables &group.*&variable./sparse outpct outexpect out=freq_out2 chisq fisher;
		output out=test_out2 chisq fisher;
	run;
	data freq_out2;
		set freq_out2;
		var1=&variable.;
		if &variable.~="";
	run;
	proc sort data=freq_g2;    by &group. var1;run;
	proc sort data=freq_out2;  by &group. var1;run;
	data fout2(keep=&group. &variable. expected n pctn_10 rename=(n=count pctn_10=pct_row));
		merge freq_out2 freq_g2;
		by &group. var1;
		if expected=. then expected=0;
	run;
	proc sort data=fout2;by &group.;run;

	data expected2;
		set fout2;
		if expected<5 then mark=1;
		else mark=0;
	run;
	proc sql noprint;
	   select avg(mark),sum(expected) into :methodselect2,:sumexpected2  from expected2;
	   quit;
	run;
	data _null_;
		set test_out2;
		if xp2_fish="  NA" then do;
			call symput("p_fisher2","  NA");
			call symput("x_fisher2","  NA");
		end;	  
		else if input(xp2_fish,best12.)~=. then do;
			call symput("p_fisher2",trim(left(put(xp2_fish,6.4))));
			call symput("x_fisher2","Fisher");
        end;
		else do;
			call symput("p_fisher2","  NA");
			call symput("x_fisher2","  NA");
        end;
		if _lrchi_="  NA" then call symput("lrchi2","  NA");
		else if input(_lrchi_,best12.)~=. then call symput("lrchi2",trim(left(put(_lrchi_,6.4))));
		else call symput("lrchi2","  NA");
		if p_lrchi="  NA" then call symput("p_lrchi2","  NA");
		else if input(p_lrchi,best12.)~=. then 	call symput("p_lrchi2",trim(left(put(p_lrchi,6.4))));
		else call symput("p_lrchi2","  NA");
	run;





	data test_out;
		length x_fish1 xp2_fish1 _lrchi1_ p_lrchi1 x_fish2 xp2_fish2 _lrchi2_ p_lrchi2 $ 8.4;
		set total_n;
	    x_fish1="&x_fisher1.";
	    xp2_fish1="&p_fisher1.";
		if xp2_fish1="0.0000" then xp2_fish1="<0.0001";

	    x_fish2="&x_fisher2.";
	    xp2_fish2="&p_fisher2.";
		if xp2_fish2="0.0000" then xp2_fish2="<0.0001";

	    _lrchi1_="&lrchi1.";
		if _lrchi1_="0.0000" then _lrchi1_="<0.0001";
	    p_lrchi1="&p_lrchi1.";
		if p_lrchi1="0.0000" then p_lrchi1="<0.0001";

	   _lrchi2_="&lrchi2.";
		if _lrchi2_="0.0000" then _lrchi2_="<0.0001";
	    p_lrchi2="&p_lrchi2.";
		if p_lrchi2="0.0000" then p_lrchi2="<0.0001";
	run;



	proc print data=test_out;run;
	proc print data=freq_out;run;




%mend M_CG_BW_R_ALL_;
