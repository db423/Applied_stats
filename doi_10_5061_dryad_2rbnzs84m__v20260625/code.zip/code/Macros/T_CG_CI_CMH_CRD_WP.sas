%macro T_CG_CI_CMH_CRD_WP(dataset=,variable=,strata=,n=,m=,yzm=,yzz=,method=,column=,delta=,labelfmt=);
    data test_out1;
	    Value="  NA";
	    LowerCL="  NA";
	    UpperCL="  NA";
    run;
	data freqdata(keep=group2 &variable. &strata.);
		set &dataset.;
		if &yzm.="&yzz.";
		if &group.="&n." then group2="1";
		if &group.="&m." then group2="2";
		if group2='' then delete;
		if input(&variable.,best12.)=. then delete;
    run; 
    proc tabulate data=freqdata out=freq_g1(drop=_type_ _page_ _table_);
		class group2 &variable./preloadfmt  ;
		/*preloadfmt��specifies that all formats are preloaded for the class variables.*/
        table &variable.*(n colpctn),group2/ printmiss row=float;
		/* Use care when you use PRELOADFMT with PRINTMISS. This feature creates all possible combinations of formatted class variables.*/
        /*row=float:divides the row title space equally among the nonblank row titles in the crossing.*/
	    format &variable.  $&variable.f.;
	run;
	data freq_g2;
		set freq_g1;
		if n=. then n=0;
		if pctn_10=. then pctn_10=0;
		format group2 group2;
		var1=&variable.;
	run;
	proc freq data=freqdata noprint ;
	    tables group2*&variable./sparse outpct outexpect out=freq_out;
	run;

	data freq_out1;
		set freq_out;
		var1=&variable.;
		if &variable.~="";
	run;
	proc sort data=freq_g2;    by group2 var1;run;
	proc sort data=freq_out1;  by group2 var1;run;
	data freq_out2(keep=group2 &variable. expected n pctn_10 rename=(n=count pctn_10=pct_row));
		merge freq_out1 freq_g2;
		by group2 var1;
		if expected=. then expected=0;
	run;
	proc sort data=freq_out2;by group2;run;
    
	ods trace on ; 
	ods output CommonPdiff=test_out2;
	proc freq data=freqdata;
		tables &strata.*group2*&variable./
		cmh 
		commonriskdiff(cl=(MH MINRISK NEWCOMBE NEWCOMBEMR SCORE ) COLUMN=&column.)
		alpha=0.0167;
	run;
	ods trace off;

	data test_out;
		length  way $12.0;
		set test_out2;
		if method='Mantel-Haenszel' then way='MH';
		if method='��С����' then way='MINRISK';
		if method='Newcombe' then way='NEWCOMBE';
		if method='Newcombe (MR)' then way='NEWCOMBEMR';
		if method='��������' then way='SCORE';
	run;

	data test_&method.;
		set test_out;
		if way="&method.";
	run;

	  data testout(keep=Value_ LowerCL_ UpperCL_ ratediffcl z pvalue);
		set test_&method.;
	   if input(Value,best12.)~=. then do;
		   Value_=round(Value*100,0.1);
		   LowerCL_=round(LowerCL*100,0.1);
		   UpperCL_=round(UpperCL*100,0.1);
		   ratediffcl=compress(Value_||'%'||' ['||LowerCL_||'%,'||UpperCL_||'%]');

		   if StdErr~=. then do;
		   z=(Value-&delta.)/StdErr;
		   pvalue=trim(left(put((1-probnorm(abs(z)))*2,6.4)));
		   end;
		   if StdErr=. then do;
		   z=(Value-&delta.)/((UpperCL-LowerCL)/2/1.96);
		   pvalue=trim(left(put((1-probnorm(abs(z)))*2,6.4)));
		   end;

       end;
			if Value="  NA" or Value=. then do;
			    ratediffcl="  NA"||" ["||"  NA,"||"  NA"||"]";
				pvalue="  NA";
			end;	  
         run;
	    data _null_;
		 	set testout;
            call symput('ratediffcl',ratediffcl);
            call symput('pvalue',pvalue);
         run;
		 %put &ratediffcl.;
		 %put &pvalue.;

	data stat(keep=group2 &variable. stat_var);
		set &dataset.;
		if &yzm.="&yzz.";
		if &group.="&n." then group2="1";
		if &group.="&m." then group2="2";
		if group2='' then delete;
		if &variable.="." then &variable.="";
		stat_var=input(&variable.,best12.);
	run;
	proc univariate data=stat noprint;
	    class group2;
	    var stat_var;
		output out=total_n n=n nmiss=nmiss;
	run;
	data test_out1;
		length  pvalue $ 8.4;
		set total_n;
	    ratediffcl="&ratediffcl.";
	    pvalue="&pvalue.";
		if pvalue~=. and pvalue<0.0001 then pvalue1="<0.0001";
		else pvalue1=pvalue;
		if _n_=1;
	run;

	proc print data=total_n;run;
	proc print data=freq_out2;run;
	data test_out1_;
	set test_out1;
	keep ratediffcl;
	run;
	proc print data=test_out1_;run;




%mend T_CG_CI_CMH_CRD_WP;




