/*Set library and the physical path for dataset; the physical path needs to be changed as appropirate*/
%let rootdir=C:\Users\wangc\validation;

libname drv  "&rootdir.";

options nodate ls=180 ps=80 options missing='.' nonumber ;
ods escapechar = '|';

options fmtsearch=(drv);
options mautosource sasautos=("&rootdir.\code\Macros",sasautos);

/*Import dataset*/
proc import datafile="&rootdir.\data\adacrm.xls" out=drv.adacrm replace;
run;
proc import datafile="&rootdir.\data\adsl.xls" out=drv.adsl replace;
run;


/*Add a group '5' for all participants to output descriptive results for total population*/
data acrmt;set drv.adacrm;group='5';run;

data drv.adacrmt;
	retain subjid group fasfl pprotfl;
	set drv.adacrm acrmt;
	if fasfl='1';
run;

/*Generate Results using macros */
                                                                     
%allfmt;

ods listing;
ods html close;
options ls=200 ps=300;

/*Figure 1 Analysis Population Determination*/
proc freq data=drv.adsl;
	tables group group*pdtype;
run;

/*Table 1 Analysis result of baseline characteristics of the participants */
	%M_CT_BW_NO(dataset=drv.adacrmt,variable=age,ParSel=2,group=group,labelfmt=Age��year��);
	%M_CG_BW_R_ALL(dataset=drv.adacrmt,variable=sex,group=group,labelfmt=Gender);
	%M_CT_BW_NO(dataset=drv.adacrmt,variable=bmi,ParSel=2,group=group,labelfmt=Body mass index��kg/m2��);
	%M_CT_BW_NO(dataset=drv.adacrmt,variable=comy,ParSel=2,group=group,labelfmt=Course of migraine��yr��);
	%M_CG_BW_R_ALL(dataset=drv.adacrmt,variable=migzz_v1,group=group,labelfmt=Migraine with aura);
	%M_CG_BW_R_ALL(dataset=drv.adacrmt,variable=pttyx,group=group,labelfmt=migraine headache frequency);
	%M_CG_BW_R_ALL_(dataset=drv.adacrmt,variable=ech_v1,group=group,labelfmt=Echo examination��TTE��);
	%M_CG_BW_R_ALL(dataset=drv.adacrmt,variable=xztee_v1,group=group,labelfmt=Echo examination��TEE��);
	%M_CG_BW_R_ALL(dataset=drv.adacrmt,variable=xztee1a_v1,group=group,labelfmt=Contrast ultrasound examination��cTTE��);
	%M_CG_BW_R_ALL(dataset=drv.adacrmt,variable=xztee1b_v1,group=group,labelfmt=Contrast ultrasound examination��cTEE��);
	%M_CG_BW_R_ALL(dataset=drv.adacrmt,variable=xztee1c_v1,group=group,labelfmt=Contrast ultrasound examination��cTCD��);
	%M_CG_BW_R_ALL(dataset=drv.adacrmt,variable=ech29_v1,group=group,labelfmt=RLS grade);
	%M_CT_BW_NO(dataset=drv.adacrmt,variable=migpl1_v1,ParSel=2,group=group,labelfmt=Migraine days at baseline��month��);
	%M_CT_BW_NO(dataset=drv.adacrmt,variable=migpl3_v1,ParSel=2,group=group,labelfmt=No. of migraine attacks at baseline��month��);
	%M_CT_BW_NO(dataset=drv.adacrmt,variable=msqr_v1,ParSel=2,group=group,labelfmt=RR domain of MSQ at baseline);
	%M_CT_BW_NO(dataset=drv.adacrmt,variable=msqp_v1,ParSel=2,group=group,labelfmt=RP domain of MSQ at baseline);
	%M_CT_BW_NO(dataset=drv.adacrmt,variable=msqe_v1,ParSel=2,group=group,labelfmt=EF domain of MSQ at baseline);

/*Table 2 Primary endpoint:Response rate descriptive analysis results*/
	%M_CG_BW_R_ALL_NT(dataset=drv.adacrmt(where=(rrydl~='')),variable=rrydl,group=group,blm=fasfl,blz=1,labelfmt=Response rate������-CC);

/*Table 2  Primary endpoint : Analysis result of differences in response rates��Level 1 and Level 2��*/
	%T_CG_CI_CMH_CRD(dataset=drv.adacrmt(where=(rrydl~='')),variable=rrydl,strata=siteida,n=1,m=4,sjj=fasfl,method=MH,column=1,delta=-15,labelfmt=Response rate������-CC��Aspirin VS Metoprolol��);
	%T_CG_CI_CMH_CRD(dataset=drv.adacrmt(where=(rrydl~='')),variable=rrydl,strata=siteida,n=1,m=4,sjj=fasfl,method=MH,column=1,delta=0,labelfmt=Response rate������-CC��Aspirin VS Metoprolol��);
	%T_CG_CI_CMH_CRD(dataset=drv.adacrmt(where=(rrydl~='')),variable=rrydl,strata=siteida,n=2,m=4,sjj=fasfl,method=MH,column=1,delta=-15,labelfmt=Response rate������-CC��Clopidogrel VS Metoprolol��);
	%T_CG_CI_CMH_CRD(dataset=drv.adacrmt(where=(rrydl~='')),variable=rrydl,strata=siteida,n=2,m=4,sjj=fasfl,method=MH,column=1,delta=0,labelfmt=Response rate������-CC��Clopidogrel VS Metoprolol��);
	%T_CG_CI_CMH_CRD(dataset=drv.adacrmt(where=(rrydl~='')),variable=rrydl,strata=siteida,n=3,m=4,sjj=fasfl,method=MH,column=1,delta=-15,labelfmt=Response rate������-CC��Rivaroxaban VS Metoprolol��);
	%T_CG_CI_CMH_CRD(dataset=drv.adacrmt(where=(rrydl~='')),variable=rrydl,strata=siteida,n=3,m=4,sjj=fasfl,method=MH,column=1,delta=0,labelfmt=Response rate������-CC��Rivaroxaban VS Metoprolol��);

/*Table 2  Primary endpoint : Analysis result of differences in response rates��Level 3��*/
	%T_CG_CI_CMH_CRD(dataset=drv.adacrmt(where=(rrydl~='')),variable=rrydl,strata=siteida,n=1,m=2,sjj=fasfl,method=MH,column=1,delta=0,labelfmt=Response rate������-CC��Aspirin VS Clopidogrel��);
	%T_CG_CI_CMH_CRD(dataset=drv.adacrmt(where=(rrydl~='')),variable=rrydl,strata=siteida,n=1,m=3,sjj=fasfl,method=MH,column=1,delta=0,labelfmt=Response rate������-CC��Aspirin VS Rivaroxaban��);
	%T_CG_CI_CMH_CRD(dataset=drv.adacrmt(where=(rrydl~='')),variable=rrydl,strata=siteida,n=2,m=3,sjj=fasfl,method=MH,column=1,delta=0,labelfmt=Response rate������-CC��Clopidogrel VS Rivaroxaban��);

/*Table2  Secondary endpoint:Descriptive analysis results*/
	%M_CT_BW_NO(dataset=drv.adacrmt(where=(group~='5')),variable=avdm,ParSel=2,group=group,labelfmt=Reduction in the mean no. of migraine days);
	%M_CT_BW_NO(dataset=drv.adacrmt(where=(group~='5')),variable=avcm,ParSel=2,group=group,labelfmt=Reduction in the mean no. of migraine attacks);
	%M_CT_BW_NO(dataset=drv.adacrmt(where=(group~='5')),variable=avdmr,ParSel=2,group=group,labelfmt=Reduction rate of the mean no. of migraine days);
	%M_CT_BW_NO(dataset=drv.adacrmt(where=(group~='5')),variable=avcmr,ParSel=2,group=group,labelfmt=Reduction rate of the mean no. of migraine attacks);
	%M_CG_BW_R_ALL_NT(dataset=drv.adacrmt(where=(group~='5')),variable=coce,group=group,blm=fasfl,blz=1,labelfmt=Complete cessation������);
	%M_CT_BW_NO(dataset=drv.adacrmt(where=(group~='5')),variable=chrr,ParSel=2,group=group,labelfmt=Changes in the RR domain of MSQ);
	%M_CT_BW_NO(dataset=drv.adacrmt(where=(group~='5')),variable=chrp,ParSel=2,group=group,labelfmt=Changes in the RP domain of MSQ);
	%M_CT_BW_NO(dataset=drv.adacrmt(where=(group~='5')),variable=chef,ParSel=2,group=group,labelfmt=Changes in the EF domain of MSQ);
	%M_CT_BW_NO(dataset=drv.adacrmt(where=(group~='5')),variable=chmsq,ParSel=2,group=group,labelfmt=Changes in the total MSQ score);

%let group=group;
/*Table 2  Results of Secondary endpoint : treatment vs active control-continuous outcome��Nonparametric tests��*/
	%T_CT_BW_CI(dataset=drv.adacrmt,variable=avdm,parsel=2,n=1,m=4,labelfmt=Reduction in monthly migraine days-Aspirin VS Metoprolol);
	%T_CT_BW_CI(dataset=drv.adacrmt,variable=avdm,parsel=2,n=2,m=4,labelfmt=Reduction in monthly migraine days-Clopidogrel VS Metoprolol);
	%T_CT_BW_CI(dataset=drv.adacrmt,variable=avdm,parsel=2,n=3,m=4,labelfmt=Reduction in monthly migraine days-Rivaroxaban VS Metoprolol);
	%T_CT_BW_CI(dataset=drv.adacrmt,variable=avcm,parsel=2,n=1,m=4,labelfmt=Reduction in monthly migraine attacks-Aspirin VS Metoprolol);
	%T_CT_BW_CI(dataset=drv.adacrmt,variable=avcm,parsel=2,n=2,m=4,labelfmt=Reduction in monthly migraine attacks-Clopidogrel VS Metoprolol);
	%T_CT_BW_CI(dataset=drv.adacrmt,variable=avcm,parsel=2,n=3,m=4,labelfmt=Reduction in monthly migraine attacks-Rivaroxaban VS Metoprolol);
	%T_CT_BW_CI(dataset=drv.adacrmt,variable=avdmr,parsel=2,n=1,m=4,labelfmt=Reduction rate of monthly migraine days-Aspirin VS Metoprolol);
	%T_CT_BW_CI(dataset=drv.adacrmt,variable=avdmr,parsel=2,n=2,m=4,labelfmt=Reduction rate of monthly migraine days-Clopidogrel VS Metoprolol);
	%T_CT_BW_CI(dataset=drv.adacrmt,variable=avdmr,parsel=2,n=3,m=4,labelfmt=Reduction rate of monthly migraine days-Rivaroxaban VS Metoprolol);
	%T_CT_BW_CI(dataset=drv.adacrmt,variable=avcmr,parsel=2,n=1,m=4,labelfmt=Reduction rate of monthly migraine attacks-Aspirin VS Metoprolol);
	%T_CT_BW_CI(dataset=drv.adacrmt,variable=avcmr,parsel=2,n=2,m=4,labelfmt=Reduction rate of monthly migraine attacks-Clopidogrel VS Metoprolol);
	%T_CT_BW_CI(dataset=drv.adacrmt,variable=avcmr,parsel=2,n=3,m=4,labelfmt=Reduction rate of monthly migraine attacks-Rivaroxaban VS Metoprolol);
	%T_CT_BW_CI(dataset=drv.adacrmt,variable=chrr,parsel=2,n=1,m=4,labelfmt=Changes in the RR domain of MSQ-Aspirin VS Metoprolol);
	%T_CT_BW_CI(dataset=drv.adacrmt,variable=chrr,parsel=2,n=2,m=4,labelfmt=Changes in the RR domain of MSQ-Clopidogrel VS Metoprolol);
	%T_CT_BW_CI(dataset=drv.adacrmt,variable=chrr,parsel=2,n=3,m=4,labelfmt=Changes in the RR domain of MSQ-Rivaroxaban VS Metoprolol);
	%T_CT_BW_CI(dataset=drv.adacrmt,variable=chrp,parsel=2,n=1,m=4,labelfmt=Changes in the RP domain of MSQ-Aspirin VS Metoprolol);
	%T_CT_BW_CI(dataset=drv.adacrmt,variable=chrp,parsel=2,n=2,m=4,labelfmt=Changes in the RP domain of MSQ-Clopidogrel VS Metoprolol);
	%T_CT_BW_CI(dataset=drv.adacrmt,variable=chrp,parsel=2,n=3,m=4,labelfmt=Changes in the RP domain of MSQ-Rivaroxaban VS Metoprolol);
	%T_CT_BW_CI(dataset=drv.adacrmt,variable=chef,parsel=2,n=1,m=4,labelfmt=Changes in the EF domain of MSQ-Aspirin VS Metoprolol);
	%T_CT_BW_CI(dataset=drv.adacrmt,variable=chef,parsel=2,n=2,m=4,labelfmt=Changes in the EF domain of MSQ-Clopidogrel VS Metoprolol);
	%T_CT_BW_CI(dataset=drv.adacrmt,variable=chef,parsel=2,n=3,m=4,labelfmt=Changes in the EF domain of MSQ-Rivaroxaban VS Metoprolol);
	%T_CT_BW_CI(dataset=drv.adacrmt,variable=chmsq,parsel=2,n=1,m=4,labelfmt=Changes in the total MSQ score-Aspirin VS Metoprolol);
	%T_CT_BW_CI(dataset=drv.adacrmt,variable=chmsq,parsel=2,n=2,m=4,labelfmt=Changes in the total MSQ score-Clopidogrel VS Metoprolol);
	%T_CT_BW_CI(dataset=drv.adacrmt,variable=chmsq,parsel=2,n=3,m=4,labelfmt=Changes in the total MSQ score-Rivaroxaban VS Metoprolol);

%let group=group;
/*Table 2   Results of Secondary endpoint : treatment vs active control-binary outcome*/
	%T_CG_BW_R2_diff(dataset=drv.adacrmt,variable=coce,n=1,m=4,labelfmt1=Complete cessation������-Aspirin VS Metoprolol,labelfmt2=);
	%T_CG_BW_R2_diff(dataset=drv.adacrmt,variable=coce,n=2,m=4,labelfmt1=Complete cessation������-Aspirin VS Metoprolol,labelfmt2=);
	%T_CG_BW_R2_diff(dataset=drv.adacrmt,variable=coce,n=3,m=4,labelfmt1=Complete cessation������-Aspirin VS Metoprolol,labelfmt2=);

/*Table 3  Analysis result of adverse events*/
	%M_CG_BW_R_ALL(dataset=drv.adacrmt,variable=ae,group=group,labelfmt=Any AEs);
	%M_CG_BW_R_ALL(dataset=drv.adacrmt,variable=impae,group=group,labelfmt=AEs related to IMPs#);
	%M_CG_BW_R_ALL(dataset=drv.adacrmt,variable=sae,group=group,labelfmt=Any SAEs);
	%M_CG_BW_R_ALL(dataset=drv.adacrmt,variable=impsae,group=group,labelfmt=SAEs related to IMPs);
	%M_CG_BW_R_ALL(dataset=drv.adacrmt,variable=bleed,group=group,labelfmt=Any bleeding);
	%M_CG_BW_R_ALL_(dataset=drv.adacrmt,variable=hemor,group=group,labelfmt=Any major bleeding);
	%M_CG_BW_R_ALL(dataset=drv.adacrmt,variable=diges,group=group,labelfmt=Gastrointestinal symptoms);
	%M_CG_BW_R_ALL(dataset=drv.adacrmt,variable=lowhr,group=group,labelfmt=Bradycardia);
	%M_CG_BW_R_ALL(dataset=drv.adacrmt,variable=lowbp,group=group,labelfmt=Hypotension);

/*Figure 2 Subgroup analysis*/
%let group=group;
/*  Age��38.5 age Subgroup : Analysis result of differences in primary endpoint response rates*/
	%T_CG_CI_CMH_CRD_WP(dataset=drv.adacrmt(where=(rrydl~='')),variable=rrydl,strata=siteida,n=1,m=4,yzm=ageyz,yzz=1,method=MH,column=1,delta=-15,labelfmt=Response rate������-CC��Aspirin VS Metoprolol��);
	%T_CG_CI_CMH_CRD_WP(dataset=drv.adacrmt(where=(rrydl~='')),variable=rrydl,strata=siteida,n=2,m=4,yzm=ageyz,yzz=1,method=MH,column=1,delta=-15,labelfmt=Response rate������-CC��Clopidogrel VS Metoprolol��);
	%T_CG_CI_CMH_CRD_WP(dataset=drv.adacrmt(where=(rrydl~='')),variable=rrydl,strata=siteida,n=3,m=4,yzm=ageyz,yzz=1,method=MH,column=1,delta=-15,labelfmt=Response rate������-CC��Rivaroxaban VS Metoprolol��);

/*  Age<38.5yr Subgroup:Analysis result of differences in primary endpoint response rates*/
	%T_CG_CI_CMH_CRD_WP(dataset=drv.adacrmt(where=(rrydl~='')),variable=rrydl,strata=siteida,n=1,m=4,yzm=ageyz,yzz=2,method=MH,column=1,delta=-15,labelfmt=Response rate������-CC��Aspirin VS Metoprolol��);
	%T_CG_CI_CMH_CRD_WP(dataset=drv.adacrmt(where=(rrydl~='')),variable=rrydl,strata=siteida,n=2,m=4,yzm=ageyz,yzz=2,method=MH,column=1,delta=-15,labelfmt=Response rate������-CC��Clopidogrel VS Metoprolol��);
	%T_CG_CI_CMH_CRD_WP(dataset=drv.adacrmt(where=(rrydl~='')),variable=rrydl,strata=siteida,n=3,m=4,yzm=ageyz,yzz=2,method=MH,column=1,delta=-15,labelfmt=Response rate������-CC��Rivaroxaban VS Metoprolol��);

/* Male Subgroup:Analysis result of differences in primary endpoint response rates*/
	%T_CG_CI_CMH_CRD_WP(dataset=drv.adacrmt(where=(rrydl~='')),variable=rrydl,strata=siteida,n=1,m=4,yzm=sex,yzz=1,method=MH,column=1,delta=-15,labelfmt=Response rate������-CC��Aspirin VS Metoprolol��);
	%T_CG_CI_CMH_CRD_WP(dataset=drv.adacrmt(where=(rrydl~='')),variable=rrydl,strata=siteida,n=2,m=4,yzm=sex,yzz=1,method=MH,column=1,delta=-15,labelfmt=Response rate������-CC��Clopidogrel VS Metoprolol��);
	%T_CG_CI_CMH_CRD_WP(dataset=drv.adacrmt(where=(rrydl~='')),variable=rrydl,strata=siteida,n=3,m=4,yzm=sex,yzz=1,method=MH,column=1,delta=-15,labelfmt=Response rate������-CC��Clopidogrel VS Rivaroxaban��);

/*  Female Subgroup:Analysis result of differences in primary endpoint response rates*/
	%T_CG_CI_CMH_CRD_WP(dataset=drv.adacrmt(where=(rrydl~='')),variable=rrydl,strata=siteida,n=1,m=4,yzm=sex,yzz=2,method=MH,column=1,delta=-15,labelfmt=Response rate������-CC��Aspirin VS Metoprolol��);
	%T_CG_CI_CMH_CRD_WP(dataset=drv.adacrmt(where=(rrydl~='')),variable=rrydl,strata=siteida,n=2,m=4,yzm=sex,yzz=2,method=MH,column=1,delta=-15,labelfmt=Response rate������-CC��Clopidogrel VS Metoprolol��);
	%T_CG_CI_CMH_CRD_WP(dataset=drv.adacrmt(where=(rrydl~='')),variable=rrydl,strata=siteida,n=3,m=4,yzm=sex,yzz=2,method=MH,column=1,delta=-15,labelfmt=Response rate������-CC��Rivaroxaban VS Metoprolol��);

/*  Migraine with aura Subgroup:Analysis result of differences in primary endpoint response rates*/
	%T_CG_CI_CMH_CRD_WP(dataset=drv.adacrmt(where=(rrydl~='')),variable=rrydl,strata=siteida,n=1,m=4,yzm=migzz_v1,yzz=1,method=MH,column=1,delta=-15,labelfmt=Response rate������-CC��Aspirin VS Metoprolol��);
	%T_CG_CI_CMH_CRD_WP(dataset=drv.adacrmt(where=(rrydl~='')),variable=rrydl,strata=siteida,n=2,m=4,yzm=migzz_v1,yzz=1,method=MH,column=1,delta=-15,labelfmt=Response rate������-CC��Clopidogrel VS Metoprolol��);
	%T_CG_CI_CMH_CRD_WP(dataset=drv.adacrmt(where=(rrydl~='')),variable=rrydl,strata=siteida,n=3,m=4,yzm=migzz_v1,yzz=1,method=MH,column=1,delta=-15,labelfmt=Response rate������-CC��Rivaroxaban VS Metoprolol��);

/*  Migraine without aura Subgroup:Analysis result of differences in primary endpoint response rates*/
	%T_CG_CI_CMH_CRD_WP(dataset=drv.adacrmt(where=(rrydl~='')),variable=rrydl,strata=siteida,n=1,m=4,yzm=migzz_v1,yzz=2,method=MH,column=1,delta=-15,labelfmt=Response rate������-CC��Aspirin VS Metoprolol��);
	%T_CG_CI_CMH_CRD_WP(dataset=drv.adacrmt(where=(rrydl~='')),variable=rrydl,strata=siteida,n=2,m=4,yzm=migzz_v1,yzz=2,method=MH,column=1,delta=-15,labelfmt=Response rate������-CC��Clopidogrel VS Metoprolol��);
	%T_CG_CI_CMH_CRD_WP(dataset=drv.adacrmt(where=(rrydl~='')),variable=rrydl,strata=siteida,n=3,m=4,yzm=migzz_v1,yzz=2,method=MH,column=1,delta=-15,labelfmt=Response rate������-CC��Rivaroxaban VS Metoprolol��);

/* RLS grade 1 Subgroup:Analysis result of differences in primary endpoint response rates*/
	%T_CG_CI_CMH_CRD_WP(dataset=drv.adacrmt(where=(rrydl~='')),variable=rrydl,strata=siteida,n=1,m=4,yzm=ech29_v1,yzz=1,method=MH,column=1,delta=-15,labelfmt=Response rate������-CC��Aspirin VS Metoprolol��);
	%T_CG_CI_CMH_CRD_WP(dataset=drv.adacrmt(where=(rrydl~='')),variable=rrydl,strata=siteida,n=2,m=4,yzm=ech29_v1,yzz=1,method=MH,column=1,delta=-15,labelfmt=Response rate������-CC��Clopidogrel VS Metoprolol��);
	%T_CG_CI_CMH_CRD_WP(dataset=drv.adacrmt(where=(rrydl~='')),variable=rrydl,strata=siteida,n=3,m=4,yzm=ech29_v1,yzz=1,method=MH,column=1,delta=-15,labelfmt=Response rate������-CC��Rivaroxaban VS Metoprolol��);

/* RLS grade2 Subgroup:Analysis result of differences in primary endpoint response rates*/
	%T_CG_CI_CMH_CRD_WP(dataset=drv.adacrmt(where=(rrydl~='')),variable=rrydl,strata=siteida,n=1,m=4,yzm=ech29_v1,yzz=2,method=MH,column=1,delta=-15,labelfmt=Response rate������-CC��Aspirin VS Metoprolol��);
	%T_CG_CI_CMH_CRD_WP(dataset=drv.adacrmt(where=(rrydl~='')),variable=rrydl,strata=siteida,n=2,m=4,yzm=ech29_v1,yzz=2,method=MH,column=1,delta=-15,labelfmt=Response rate������-CC��Clopidogrel VS Metoprolol��);
	%T_CG_CI_CMH_CRD_WP(dataset=drv.adacrmt(where=(rrydl~='')),variable=rrydl,strata=siteida,n=3,m=4,yzm=ech29_v1,yzz=2,method=MH,column=1,delta=-15,labelfmt=Response rate������-CC��Rivaroxaban VS Metoprolol��);

/* RLS grade 3 Subgroup:Analysis result of differences in primary endpoint response rates*/
	%T_CG_CI_CMH_CRD_WP(dataset=drv.adacrmt(where=(rrydl~='')),variable=rrydl,strata=siteida,n=1,m=4,yzm=ech29_v1,yzz=3,method=MH,column=1,delta=-15,labelfmt=Response rate������-CC��Aspirin VS Metoprolol��);
	%T_CG_CI_CMH_CRD_WP(dataset=drv.adacrmt(where=(rrydl~='')),variable=rrydl,strata=siteida,n=2,m=4,yzm=ech29_v1,yzz=3,method=MH,column=1,delta=-15,labelfmt=Response rate������-CC��Clopidogrel VS Metoprolol��);
	%T_CG_CI_CMH_CRD_WP(dataset=drv.adacrmt(where=(rrydl~='')),variable=rrydl,strata=siteida,n=3,m=4,yzm=ech29_v1,yzz=3,method=MH,column=1,delta=-15,labelfmt=Response rate������-CC��Rivaroxaban VS Metoprolol��);

/*  Subgroup analysis: Interaction test between intervention and subgroups */
	%macro jhp(data,n,m,var);
	data &data.;
		set drv.adacrmt;
		if group="&n."  or group="&m.";
		if group="&n." then group="1";
		if group="&m." then group="2";
		if group='' then delete;
	run;
	proc logistic data=&data.(where=(rrydl~='')); 
		class group(ref='2'); 
		model rrydl=group|&var. /risklimits; 
	run;
	%mend;
	%macro jhpr(data,n,m,var,ref);
	data &data.;
		set drv.adacrmt;
		if group="&n."  or group="&m.";
		if group="&n." then group="1";
		if group="&m." then group="2";
		if group='' then delete;
	run;
	proc logistic data=&data.(where=(rrydl~='')); 
		class group(ref='2') &var(ref="&ref."); 
		model rrydl=group|&var. /risklimits; 
	run;*;
	%mend;
	%jhp(adam,1,4,age);%jhpr(adam,1,4,sex,1);%jhpr(adam,1,4,migzz_v1,2);%jhpr(adam,1,4,ech29_v1,1);
	%jhp(adcm,2,4,age);%jhpr(adcm,2,4,sex,1);%jhpr(adcm,2,4,migzz_v1,2);%jhpr(adcm,2,4,ech29_v1,1);
	%jhp(adrm,3,4,age);%jhpr(adrm,3,4,sex,1);%jhpr(adrm,3,4,migzz_v1,2);%jhpr(adrm,3,4,ech29_v1,1);







